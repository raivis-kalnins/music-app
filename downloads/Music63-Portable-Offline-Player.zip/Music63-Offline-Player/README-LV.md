# Music 63 Offline Player — Windows, Mac, Android, iPad

Šis ir atsevišķs **bezsaistes atskaņotājs** Music 63 ierakstu studijai. Tam nav jāievada Music 63 lietotājvārds vai parole. Ieraksti un MIDI faili paliek ierīcē.

## Windows 11 un Mac (ZIP bez EXE)

1. Izpako visu ZIP, saglabājot failus vienā mapē `Music63-Offline-Player`.
2. Atver `index.html` pārlūkā **Google Chrome vai Microsoft Edge**. Nekādu `.exe` vai `.app` nevajag palaist.
3. Nospied **Ieslēgt skaņu**. Datoram pievienotai 88 taustiņu USB MIDI klaviatūrai nospied **Pieslēgt MIDI** un atļauj piekļuvi, ja pārlūks to piedāvā.
4. Tumbiņas pieslēdz ar audio kabeli; Bluetooth radīs aizturi dzīvai klavierspēlei.
5. Ar **Izvēlēties MIDI, WAV vai MP3** atver failu; viss paliek lokāli.

**Alternatīva PWA instalācija:** vienreiz ar internetu atver `https://music.63.lv/offline-player/`, Chrome/Edge izvēlnē izvēlies **Install app**. Sagaidi statusu **Saglabāts bezsaistē ✓**, pēc tam pārbaudi lietotni bez interneta.

## Android

Atver `https://music.63.lv/offline-player/` Android Chrome → izvēlne `⋮` → **Install app**. Atver lietotni ar internetu vienu reizi, sagaidi bezsaistes saglabāšanas statusu, un tad lieto bez interneta. USB MIDI nepieciešams atbalstīts tālrunis/planšete, USB OTG un pārlūka atļauja. Garantēt saderību ar jebkuru aparatūru nevar.

## Apple iPad (iPadOS)

Safari atver `https://music.63.lv/offline-player/` → **Share → Add to Home Screen → Open as Web App → Add**. MIDI failus un audio ierakstus var atskaņot, kā arī izmantot ekrāna klavieres. Safari **neatbalsta Web MIDI**, tādēļ tiešam ārējās MIDI klaviatūras savienojumam vajadzīga atsevišķa iPad native MIDI lietotne.

## Failu formāti un ierobežojumi

- `.mid/.midi`: standarta MIDI 0 un 1 formāta atskaņošana ar lokālo Web Audio instrumentu skaņu banku; instrumentu skaņa var atšķirties no Ableton un pilnās Music 63 studijas.
- `.wav/.mp3/.ogg/.m4a`: atskaņošana izmantojot pārlūka audio dekoderi; atsevišķu formātu atbalsts atkarīgs no ierīces.
- MIDI skaņu banka ir iegūta no Music 63 esošajiem skaņu paraugiem. Tas nav jauns profesionāli ierakstīts VST instruments.
- PWA offline saglabā atskaņotāja kodu un instrumentu banku; tā **nesinhronizē Music 63 servera ierakstus**. Vispirms eksportē savu ierakstu kā WAV vai MIDI un atver to atskaņotājā.
- PWA nav native Android `.apk`, iPad `.ipa` vai parakstīta macOS `.dmg`. Lietotāju konts/Apple developer sertifikāts šai PWA versijai nav vajadzīgs.

## Drošība un SmartScreen

Iepriekšējais `Music63PortablePlayer.exe` nebija digitāli parakstīts, tādēļ Windows to varēja apstādināt ar SmartScreen. Šis ZIP **nesatur Windows EXE**: to var atvērt Chrome/Edge kā vietējos HTML/JS failus bez SmartScreen .exe paziņojuma. Tas neaizstāj antivīrusa pārbaudi un nav garantija, ka visi Windows drošības dialogi izzudīs.

Lai nākotnē izplatītu uzticamu native EXE, jāizmanto Microsoft Store vai verificēta izdevēja paraksts un jāveido reputācija. Neatslēdz SmartScreen vai Smart App Control.

## Papildu saite

- Web studija: `https://music.63.lv/`
- Offline player: `https://music.63.lv/offline-player/`
