/* Music 63 standalone SMF parser. No external libraries or network requests. */
(function (global) {
  'use strict';
  function parseMidiFile(data) {
    const bytes = data instanceof Uint8Array ? data : new Uint8Array(data);
    if (bytes.byteLength > 16 * 1024 * 1024) throw Error('MIDI fails ir par lielu (maksimums 16 MB).');
    let pos = 0, eventCount = 0;
    const need = n => { if (pos + n > bytes.length) throw Error('Bojāts MIDI fails (nepilnīgi dati).'); };
    const u8 = () => { need(1); return bytes[pos++]; };
    const u16 = () => ((u8() << 8) | u8()) >>> 0;
    const u32 = () => (((u8() * 0x1000000) + (u8() << 16) + (u8() << 8) + u8())) >>> 0;
    const text = n => { need(n); let s = ''; for (let i = 0; i < n; i++) s += String.fromCharCode(u8()); return s; };
    const vlq = () => { let v = 0; for (let i = 0; i < 4; i++) { const b = u8(); v = v * 128 + (b & 127); if (!(b & 128)) return v; } throw Error('Nederīgs MIDI laika kods.'); };
    if (text(4) !== 'MThd') throw Error('Nav derīgs MIDI (MThd) fails.');
    const hdLength = u32();
    if (hdLength < 6 || hdLength > 256) throw Error('Nederīga MIDI galvene.');
    const format = u16(), tracksCount = u16(), division = u16();
    need(hdLength - 6); pos += hdLength - 6;
    if (format > 1 || tracksCount < 1 || tracksCount > 128) throw Error('Atbalstīti tikai MIDI 0/1 faili līdz 128 celiņiem.');
    if (division & 0x8000 || division === 0) throw Error('SMPTE MIDI laika kods nav atbalstīts.');
    if (bytes.length < 14) throw Error('Nepilnīgs MIDI fails.');
    const events = [], tempos = [{ tick: 0, us: 500000, track: -1 }];
    let endTick = 0;
    for (let tr = 0; tr < tracksCount; tr++) {
      if (text(4) !== 'MTrk') throw Error('MIDI celiņam trūkst MTrk galvenes.');
      const length = u32(), end = pos + length;
      if (end > bytes.length) throw Error('MIDI celiņš pārsniedz faila garumu.');
      let tick = 0, running = 0;
      while (pos < end) {
        tick += vlq();
        if (tick > 0x7fffffff) throw Error('MIDI laiks ir pārāk liels.');
        let status = u8();
        if (status < 0x80) {
          if (!running) throw Error('MIDI bez statusa baita.');
          pos--; status = running;
        } else if (status < 0xF0) running = status;
        else running = 0;
        if (status === 0xFF) {
          const type = u8(), len = vlq();
          if (pos + len > end) throw Error('MIDI meta notikums pārsniedz celiņu.');
          if (type === 0x51 && len === 3) {
            const us = (bytes[pos] << 16) | (bytes[pos + 1] << 8) | bytes[pos + 2];
            if (us > 10000 && us < 10000000) tempos.push({ tick, us, track: tr });
          }
          pos += len;
          if (type === 0x2F) { pos = end; break; }
        } else if (status === 0xF0 || status === 0xF7) {
          const len = vlq(); if (pos + len > end) throw Error('Bojāts MIDI SysEx notikums.'); pos += len;
        } else if (status >= 0xF0) {
          throw Error('Neatbalstīts MIDI sistēmas notikums.');
        } else {
          const kind = status & 0xF0, channel = status & 15;
          const first = u8(), second = (kind === 0xC0 || kind === 0xD0) ? 0 : u8();
          if ((first | second) > 127) throw Error('Nederīga MIDI ziņojuma vērtība.');
          if ([0x80, 0x90, 0xB0, 0xC0].includes(kind)) {
            events.push({ tick, tr, kind, channel, note: first, value: second });
            if (++eventCount > 300000) throw Error('MIDI failā pārāk daudz notikumu.');
          }
        }
      }
      pos = end;
      if (tick > endTick) endTick = tick;
    }
    tempos.sort((a,b) => a.tick - b.tick || a.track - b.track);
    let lastTick = 0, micros = 0, currentTempo = 500000, previous = null;
    const timeline = [];
    for (const t of tempos) {
      micros += (t.tick - lastTick) * currentTempo / division;
      lastTick = t.tick; currentTempo = t.us;
      if (previous && previous.tick === t.tick) timeline[timeline.length - 1] = { tick: t.tick, secs: micros / 1e6, us: t.us };
      else timeline.push({ tick: t.tick, secs: micros / 1e6, us: t.us });
      previous = t;
    }
    function secondsAt(tick) {
      let low = 0, high = timeline.length - 1;
      while (low < high) { const mid = Math.ceil((low + high) / 2); if (timeline[mid].tick <= tick) low = mid; else high = mid - 1; }
      const t = timeline[low]; return t.secs + (tick - t.tick) * t.us / division / 1e6;
    }
    events.sort((a,b) => a.tick - b.tick || ((a.kind === 0x80 || (a.kind === 0x90 && a.value === 0)) ? -1 : 1) - ((b.kind === 0x80 || (b.kind === 0x90 && b.value === 0)) ? -1 : 1) || a.tr - b.tr);
    for (const ev of events) ev.time = secondsAt(ev.tick);
    const duration = secondsAt(endTick);
    if (!isFinite(duration) || duration > 6 * 3600) throw Error('MIDI ieraksts ir pārāk garš.');
    return { format, tracks: tracksCount, division, events, duration, bpm: Math.round(60000000 / timeline[0].us), tempoChanges: timeline.length };
  }
  const api = { parseMidiFile };
  global.Music63MidiParser = api;
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
})(typeof window !== 'undefined' ? window : globalThis);
